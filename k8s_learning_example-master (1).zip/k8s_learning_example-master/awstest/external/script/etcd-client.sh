
sudo apt install etcd-client -y