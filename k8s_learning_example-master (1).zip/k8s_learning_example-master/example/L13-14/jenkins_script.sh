# Jenkins note
# 1. Create Credentials as Service Account
# 2. Use jenkinsfile (from L12/lab1)
# 3. Config credentials ID

