
kubectl run mypod --image=nginx

kubectl ger pod mypod

kubectl describe pod mypod

kubectl describe pod nginx4

kubectl get ns

kubectl create ns testns

kubectl create pod x -n testns

kubectl delete ns testns