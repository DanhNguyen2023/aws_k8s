## Definition

-   This is a tool help you to visualize your pod, service, deployment, ...
-   Need zero config

```
kubectl apply -f https://raw.githubusercontent.com/spekt8/spekt8/master/spekt8-deployment.yaml
kubectl port-forward deployment/spekt8 3000:3000
```
