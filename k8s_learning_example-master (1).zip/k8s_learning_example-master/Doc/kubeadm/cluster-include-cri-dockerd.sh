# This script tested on k8s v1.23.6, Ubuntu 20.04 
# 


sudo kubeadm init --v=5