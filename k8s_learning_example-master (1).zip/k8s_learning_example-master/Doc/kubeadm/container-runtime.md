k8s include multiple type of container runtimes:

-   CRI-O
    ?
-   Docker
    ?

-   containerd
    ?

-   Miratis Container Runtime (MCR) (previously known as Docker Enterprise Edition.)
    Check open source `cri-dockerd`
