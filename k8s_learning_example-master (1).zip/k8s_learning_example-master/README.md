## Project

This is the project example for learning k8s. It includes:

1. **terraform**: code inside folder awstest for provisioning AWS resources used in lab sections
2. **Doc**: Summary notes about every part which will be cover in this project
3. **example**: Script lab (result) for refering in the future

